import { Routes } from '@angular/router';
import { StatusPageComponent } from './status-page.component';

export const routes: Routes = [
  {
    path: 'status',
    component: StatusPageComponent,
  },
];
