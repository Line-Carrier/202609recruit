import { ComponentFixture, TestBed } from '@angular/core/testing';
import { App } from './app';
import { AuthService } from './auth.service';

describe('App', () => {
  let fixture: ComponentFixture<App>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [AuthService],
    }).compileComponents();

    fixture = TestBed.createComponent(App);
  });

  it('creates the login screen', () => {
    expect(fixture.componentInstance).toBeTruthy();
  });
});
